let charactor = prompt('What is ur fav char?');
console.log(charactor + " is ur favortie charactor.");
let char_color = prompt('What is the main color of ' + charactor + '?');
console.log(charactor + ' is ' + char_color);